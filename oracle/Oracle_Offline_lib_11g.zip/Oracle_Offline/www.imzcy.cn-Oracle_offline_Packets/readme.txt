from: https://www.imzcy.cn
date: 2018-06-11

linux下离线安装oracle 11g时所需的依赖包，经验证可以在CentOS 7上成功离线安装oracle 11g。

